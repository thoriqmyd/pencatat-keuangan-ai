export type ParsedTransaction = {
  amount: number; category: string; wallet: string;
  type: "INCOME" | "EXPENSE"; confidence: number; rawText: string;
};

const rules: Record<string, string> = {
  kopi: "Jajan Kopi", makan: "Makan Harian", nasi: "Makan Harian",
  ojol: "Transportasi", gojek: "Transportasi", grab: "Transportasi",
  kos: "Kos", listrik: "Tagihan", pulsa: "Tagihan",
  paylater: "Paylater", gaji: "Pendapatan"
};

export function parseTransactionText(text: string): ParsedTransaction {
  const n = text.toLowerCase();
  const match = n.match(/(?:rp\.?\s*)?([0-9][0-9.,]*)\s*(k|rb|ribu|jt|juta)?/i);
  let amount = 0;
  if (match) {
    const number = Number(match[1].replace(/[.,]/g, ""));
    const suffix = match[2]?.toLowerCase();
    amount = ["k", "rb", "ribu"].includes(suffix ?? "") ? number * 1000 :
      ["jt", "juta"].includes(suffix ?? "") ? number * 1000000 : number;
  }
  let category = "Lain-lain";
  for (const [key, value] of Object.entries(rules)) {
    if (n.includes(key)) { category = value; break; }
  }
  const type = /(gaji|terima|masuk|pendapatan)/i.test(n) ? "INCOME" : "EXPENSE";
  return { amount, category, wallet: "Tunai", type,
    confidence: amount > 0 && category !== "Lain-lain" ? 0.91 : 0.62, rawText: text };
}
export function arthaConfirmation(p: ParsedTransaction) {
  return `Aku menangkap ${p.type === "EXPENSE" ? "pengeluaran" : "pemasukan"} Rp${p.amount.toLocaleString("id-ID")} untuk ${p.category} melalui ${p.wallet}. Sudah benar? 😊`;
}
