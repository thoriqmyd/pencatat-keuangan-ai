 "use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
export default function Onboarding() {
  const [form,setForm]=useState({fullName:"",email:"",phoneNumber:""});
  const [message,setMessage]=useState("");
  const router=useRouter();
  async function submit(e:React.FormEvent){e.preventDefault();setMessage("Membuat profil...");
    const r=await fetch("/api/onboarding",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)});
    const d=await r.json(); if(!r.ok)return setMessage(d.error||"Gagal");
    router.push("/onboarding/success?telegram="+encodeURIComponent(d.telegramDeepLink));
  }
  return <main className="mx-auto max-w-xl px-6 py-16"><h1 className="text-4xl font-black">Mulai rencana uangmu</h1>
    <form onSubmit={submit} className="mt-8 space-y-4 rounded-3xl bg-white p-6 shadow">
      {(["fullName","email","phoneNumber"] as const).map(k=><input key={k} required placeholder={k} value={form[k]} onChange={e=>setForm({...form,[k]:e.target.value})} className="w-full rounded-2xl border p-3"/>)}
      <button className="w-full rounded-full bg-emerald-500 p-3 font-bold text-white">Buat Profil →</button>
      <p>{message}</p>
    </form></main>;
}
