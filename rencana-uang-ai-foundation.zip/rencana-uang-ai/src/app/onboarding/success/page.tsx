export default async function Success({searchParams}:{searchParams:Promise<{telegram?:string}>}) {
  const p=await searchParams;
  return <main className="mx-auto max-w-xl px-6 py-20 text-center"><div className="rounded-3xl bg-white p-8 shadow">
    <div className="text-5xl">🎉</div><h1 className="mt-4 text-4xl font-black">Profil berhasil dibuat</h1>
    <p className="mt-3 text-slate-600">Hubungkan akun Telegram untuk mulai menggunakan Artha.</p>
    <a href={p.telegram||"#"} className="mt-8 inline-block rounded-full bg-emerald-500 px-6 py-4 font-bold text-white">Aktifkan Telegram →</a>
  </div></main>;
}
