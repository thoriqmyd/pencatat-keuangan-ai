import "./globals.css";
export const metadata = { title: "RencanaUang AI", description: "AI Financial Copilot" };
export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="id"><body>{children}</body></html>;
}
