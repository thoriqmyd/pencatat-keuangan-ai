import {NextResponse} from "next/server";
import {prisma} from "@/lib/prisma";
export async function GET(){
 const u=await prisma.user.findFirst({include:{categories:true,transactions:true}});
 if(!u)return NextResponse.json({totalIncome:5000000,totalExpense:1850000,remaining:3150000,categories:[
 {name:"Makan Harian",allocated:1500000,spent:850000,remaining:650000},{name:"Jajan Kopi",allocated:300000,spent:220000,remaining:80000},{name:"Transportasi",allocated:500000,spent:380000,remaining:120000},{name:"Kos",allocated:1500000,spent:1500000,remaining:0}],chart:[{name:"Minggu 1",income:5000000,expense:850000},{name:"Minggu 2",income:0,expense:1000000}]});
 const income=u.transactions.filter(t=>t.type==="INCOME").reduce((s,t)=>s+Number(t.amount),0);
 const expense=u.transactions.filter(t=>t.type==="EXPENSE").reduce((s,t)=>s+Number(t.amount),0);
 const categories=u.categories.filter(c=>c.type==="EXPENSE").map(c=>{const spent=u.transactions.filter(t=>t.categoryId===c.id&&t.type==="EXPENSE").reduce((s,t)=>s+Number(t.amount),0);const allocated=Number(c.allocatedAmount);return{name:c.name,allocated,spent,remaining:allocated-spent}});
 return NextResponse.json({totalIncome:income,totalExpense:expense,remaining:income-expense,categories,chart:[]});
}
