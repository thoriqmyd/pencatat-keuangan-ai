import {NextResponse} from "next/server";
import {z} from "zod";
import {prisma} from "@/lib/prisma";
import crypto from "crypto";
const schema=z.object({fullName:z.string().min(2),email:z.string().email(),phoneNumber:z.string().min(8)});
export async function POST(req:Request){
 try{const i=schema.parse(await req.json());const u=await prisma.user.create({data:{...i,status:"PENDING",
 wallets:{create:[{name:"Tunai"},{name:"Gopay"},{name:"Bank"}]},
 categories:{create:["Makan Harian","Jajan Kopi","Transportasi","Kos","Tagihan","Paylater","Pendapatan"].map(name=>({name,type:name==="Pendapatan"?"INCOME":"EXPENSE",allocatedAmount:0}))}}});
 const token=crypto.randomBytes(24).toString("hex");const bot=process.env.TELEGRAM_BOT_USERNAME||"RencanaUangBot";
 return NextResponse.json({userId:u.id,telegramDeepLink:`https://t.me/${bot}?start=${u.id}.${token}`});
 }catch{return NextResponse.json({error:"Data tidak valid atau sudah terdaftar."},{status:400});}
}
