import {NextResponse} from "next/server";
export async function GET(req:Request){const u=new URL(req.url);if(u.searchParams.get("hub.verify_token")===process.env.WHATSAPP_VERIFY_TOKEN)return new Response(u.searchParams.get("hub.challenge")||"");return new Response("Forbidden",{status:403});}
export async function POST(req:Request){const payload=await req.json();console.log("WhatsApp webhook",payload);return NextResponse.json({received:true});}
