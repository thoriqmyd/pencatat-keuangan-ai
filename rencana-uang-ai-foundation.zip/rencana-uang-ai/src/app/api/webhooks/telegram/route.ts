import {NextResponse} from "next/server";
import {parseTransactionText,arthaConfirmation} from "@/lib/artha";
export async function POST(req:Request){
 const u=await req.json();const text=u?.message?.text as string|undefined;
 if(!text)return NextResponse.json({ok:true});
 if(text.startsWith("/start"))return NextResponse.json({ok:true,reply:"Halo! Aku Artha. Aktivasi akun sedang diproses."});
 if(text.startsWith("/saldo"))return NextResponse.json({ok:true,reply:"Saldo tersedia setelah akun terhubung."});
 const p=parseTransactionText(text);return NextResponse.json({ok:true,reply:arthaConfirmation(p),parsed:p});
}
