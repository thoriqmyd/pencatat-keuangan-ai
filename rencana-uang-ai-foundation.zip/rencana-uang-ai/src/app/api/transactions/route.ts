import {NextResponse} from "next/server";
import {z} from "zod";
import {prisma} from "@/lib/prisma";
import {parseTransactionText} from "@/lib/artha";
const schema=z.object({userId:z.string(),text:z.string().min(2),sourceChannel:z.string().default("WEB")});
export async function POST(req:Request){
 const i=schema.parse(await req.json());const p=parseTransactionText(i.text);
 const u=await prisma.user.findUnique({where:{id:i.userId},include:{wallets:true,categories:true}});
 if(!u)return NextResponse.json({error:"User tidak ditemukan"},{status:404});
 const c=u.categories.find(x=>x.name===p.category);const w=u.wallets.find(x=>x.name.toLowerCase()===p.wallet.toLowerCase())||u.wallets[0];
 await prisma.aiProcessingLog.create({data:{userId:u.id,inputType:"TEXT",rawTextExtracted:i.text,parsedJson:p,confidenceScore:p.confidence,status:p.confidence>.85?"CONFIRMED":"PENDING"}});
 if(p.confidence<=.85||!c||!w)return NextResponse.json({requiresConfirmation:true,parsed:p});
 const t=await prisma.transaction.create({data:{userId:u.id,walletId:w.id,categoryId:c.id,amount:p.amount,type:p.type,sourceChannel:i.sourceChannel}});
 return NextResponse.json({requiresConfirmation:false,parsed:p,transaction:t});
}
