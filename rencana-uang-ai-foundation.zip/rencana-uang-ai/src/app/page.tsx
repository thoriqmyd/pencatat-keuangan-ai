import Link from "next/link";
export default function Page() {
  return <main className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-amber-50">
    <nav className="mx-auto flex max-w-6xl justify-between px-6 py-6">
      <b className="text-2xl">Rencana<span className="text-emerald-500">Uang</span> AI</b>
      <Link href="/onboarding" className="rounded-full bg-emerald-500 px-5 py-3 font-bold text-white">Mulai Sekarang →</Link>
    </nav>
    <section className="mx-auto grid max-w-6xl gap-12 px-6 py-20 md:grid-cols-2 md:items-center">
      <div><p className="font-bold uppercase tracking-widest text-emerald-600">AI Financial Copilot</p>
      <h1 className="mt-4 text-5xl font-black leading-tight md:text-7xl">Cuma lewat chat, keuanganmu lebih terarah.</h1>
      <p className="mt-6 text-lg text-slate-600">Catat pengeluaran lewat Web, Telegram, atau WhatsApp. Artha membantu mengatur budget berbasis zero-based budgeting.</p>
      <Link href="/onboarding" className="mt-8 inline-block rounded-full bg-emerald-500 px-6 py-4 font-bold text-white">Buat Rencana Gratis</Link></div>
      <div className="rounded-[2rem] bg-emerald-500 p-8 text-white"><b>Artha · online</b>
      <div className="mt-8 space-y-4"><div className="ml-auto max-w-xs rounded-2xl bg-white/20 p-4">Beli kopi 22k via Gopay</div>
      <div className="max-w-sm rounded-2xl bg-white p-4 text-slate-900">Aku menangkap pengeluaran Rp22.000 untuk Jajan Kopi. Sudah benar? 😊</div></div></div>
    </section>
  </main>;
}
