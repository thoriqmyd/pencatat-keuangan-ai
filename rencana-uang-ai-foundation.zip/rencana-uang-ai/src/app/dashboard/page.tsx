 "use client";
import {useEffect,useState} from "react";
import {BarChart,Bar,XAxis,YAxis,Tooltip,ResponsiveContainer} from "recharts";
import {rupiah} from "@/lib/format";
export default function Dashboard(){
 const [d,setD]=useState<any>(null); useEffect(()=>{fetch("/api/dashboard").then(r=>r.json()).then(setD)},[]);
 if(!d)return <main className="p-8">Memuat dashboard...</main>;
 return <main className="mx-auto max-w-7xl px-6 py-8"><h1 className="text-4xl font-black">Dashboard Keuangan</h1>
 <div className="mt-8 grid gap-4 md:grid-cols-3">{[["Pemasukan",d.totalIncome],["Pengeluaran",d.totalExpense],["Sisa Dana",d.remaining]].map(([a,v],i)=><div className={"rounded-3xl p-5 shadow-sm "+(i===2?"bg-emerald-500 text-white":"bg-white")} key={String(a)}><p>{a}</p><h2 className="mt-2 text-3xl font-black">{rupiah(v)}</h2></div>)}</div>
 <div className="mt-6 grid gap-6 lg:grid-cols-2"><section className="rounded-3xl bg-white p-5"><h2 className="text-xl font-black">Income vs Expense</h2><div className="h-72"><ResponsiveContainer width="100%" height="100%"><BarChart data={d.chart}><XAxis dataKey="name"/><YAxis/><Tooltip/><Bar dataKey="income"/><Bar dataKey="expense"/></BarChart></ResponsiveContainer></div></section>
 <section className="rounded-3xl bg-white p-5"><h2 className="text-xl font-black">Envelope Budget</h2>{d.categories.map((c:any)=><div className="mt-5" key={c.name}><div className="flex justify-between text-sm"><b>{c.name}</b><span>{rupiah(c.spent)} / {rupiah(c.allocated)}</span></div><div className="mt-2 h-3 rounded-full bg-slate-100"><div className={"h-full rounded-full "+(c.remaining<0?"bg-red-500":"bg-emerald-500")} style={{width:`${c.allocated?Math.min(100,c.spent/c.allocated*100):0}%`}}/></div><small>{c.remaining<0?"Overbudget":"Sisa "+rupiah(c.remaining)}</small></div>)}</section></div></main>;
}
