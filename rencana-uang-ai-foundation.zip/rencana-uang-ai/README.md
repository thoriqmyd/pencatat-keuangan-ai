# RencanaUang AI

Fondasi Next.js + Prisma + PostgreSQL untuk AI Financial Copilot berbasis Zero-Based Budgeting.

## Lokal

```bash
npm install
cp .env.example .env
npx prisma generate
npx prisma db push
npm run dev
```

## GitHub

```bash
git init
git add .
git commit -m "Initial RencanaUang AI foundation"
git branch -M main
git remote add origin https://github.com/USERNAME/rencana-uang-ai.git
git push -u origin main
```

## Vercel

1. Import repository di https://vercel.com/new.
2. Tambahkan semua variabel dari `.env.example` pada Project Settings → Environment Variables.
3. Deploy.
4. Jalankan `npx prisma migrate deploy` dari environment yang memiliki akses database.
5. Set Telegram webhook ke:
   `https://api.telegram.org/bot<TOKEN>/setWebhook?url=https://DOMAIN.vercel.app/api/webhooks/telegram`
6. Daftarkan callback WhatsApp Cloud API ke `/api/webhooks/whatsapp`.

## Catatan produksi

Starter ini belum mencakup autentikasi, authorization, penyimpanan token aktivasi yang di-hash, signature verification, queue, rate limiting, OpenAI/Whisper/Vision calls, dan export XLSX/CSV. Semua itu wajib ditambahkan sebelum digunakan dengan data finansial nyata.
